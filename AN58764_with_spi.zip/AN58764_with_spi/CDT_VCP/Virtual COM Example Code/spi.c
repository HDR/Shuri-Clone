#include <stdio.h>
#include "fx2.h"
#include "fx2regs.h"
#include "fx2sdly.h"
#include "types.h"

/* defines section  */

#define SPI_CLK PA0
#define MOSI    PA1
#define MISO    PA2
#define SPI_SS  PA3

/* global variables */

/* None */

/* local variables */

/* None */

/* prototypes section */

/* None */

/* 
================================================================
=
= Function:     spi_byte_write
=
= Description:
=
= write a byte out over bit banged spi line
= (caller manages SPI_CS signal)
=
================================================================ 
*/
void spi_byte_write(unsigned char byte)
{
    U8 i;
    
	/* Loop through each bit */
    for (i = 0; i < 8; i++) 
	{
		if (byte & 0x80)
		{
			MOSI = 1;
		}
		else
		{
			MOSI = 0;
		}
	
		SPI_CLK = 1;

        SYNCDELAY;
		SYNCDELAY;
				
		SPI_CLK = 0;

		byte = byte << 1;	
	}
}

/* 
================================================================
=
= Function:     spi_byte_read
=
= Description:
=
= read a byte out over bit banged spi line
= (caller manages SPI_CS signal)
=
================================================================ 
*/
unsigned char spi_byte_read(void)
{
    U8 i;
    U8 ret_val;

    ret_val = 0;

    SYNCDELAY;

    for (i = 0; i < 8; i++)
	{
        SYNCDELAY;
		SPI_CLK = 1;
		ret_val = ret_val << 1;
	
		if (MISO == 1)
		{
		    ret_val |= 0x01;
		}
		else
		{
		    ret_val &= 0xFE;
		}

		SPI_CLK = 0;
	}

    return ret_val;
}
 
