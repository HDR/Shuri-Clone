#pragma NOIV               // Do not generate interrupt vectors
//-----------------------------------------------------------------------------
//   File:      bulkloop.c
//   Contents:   Hooks required to implement USB peripheral function.
//
//   Copyright (c) 2000 Cypress Semiconductor All rights reserved
//-----------------------------------------------------------------------------
#include "fx2.h"
#include "fx2regs.h"
#include "fx2sdly.h"			// SYNCDELAY macro
extern BOOL   GotSUD;         // Received setup data flag
extern BOOL   Sleep;
extern BOOL   Rwuen;
extern BOOL   Selfpwr;

/* serial flash op-codes  */
#define PAGE_WRITE           0x02
#define STATUS_READ          0x05
#define WRITE_ENABLE         0x06
#define READ_FAST            0x0B
#define BULK_ERASE           0xC7

#define PAGE_SIZE            256

/* spi pinout */
#define SPI_CLK              PA0
#define SPI_SS               PA3

static unsigned char         data_packet_cnt = 0;

BYTE   Configuration;      // Current configuration
BYTE   AlternateSetting;   // Alternate settings

void display_product(void);
void TD_Poll(void);

extern void spi_byte_write(unsigned char byte);
extern unsigned char spi_byte_read(void);


//-----------------------------------------------------------------------------
// Task Dispatcher hooks
//   The following hooks are called by the task dispatcher.
//-----------------------------------------------------------------------------
BOOL DR_SetConfiguration();

void TD_Init(void)             // Called once at startup
{
    // set the CPU clock to 48MHz
    CPUCS = ((CPUCS & ~bmCLKSPD) | bmCLKSPD1) ;

    // set the slave FIFO interface to 48MHz
    IFCONFIG |= 0x40;
    SYNCDELAY;
    REVCTL = 0x03;
    SYNCDELAY;

	 FIFORESET = 0x80; // activate NAK-ALL to avoid race conditions
	 SYNCDELAY;       // see TRM section 15.14
	 FIFORESET = 0x08; // reset, FIFO 8
	 SYNCDELAY; //
	 FIFORESET = 0x00; // deactivate NAK-ALL
	 SYNCDELAY;

 	 EP1OUTCFG = 0xA0;    // Configure EP1OUT as BULK EP
	 SYNCDELAY;
     EP1INCFG = 0xB0;     // Configure EP1IN as BULK IN EP
     SYNCDELAY;                    // see TRM section 15.14
     EP2CFG = 0x7F;       // Invalid EP
     SYNCDELAY;                    
     EP4CFG = 0x7F;      // Invalid EP
     SYNCDELAY;                    
     EP6CFG = 0x7F;      // Invalid EP
     SYNCDELAY;   

     EP8CFG = 0xE0;      // Configure EP8 as BULK IN EP
     SYNCDELAY;    
  
     EP8FIFOCFG = 0x00;  // Configure EP8 FIFO in 8-bit Manual Commit mode
     SYNCDELAY;  	 	 

	 EPIE |= bmBIT3 ;              // Enable EP1 OUT Endpoint interrupts
	   
	 AUTOPTRSETUP |= 0x01;         // enable dual autopointer feature
	 Rwuen = TRUE;                 // Enable remote-wakeup
	 EP1OUTBC = 0x04;

     /* PORT A CONFIG FOR SPI, PA0=SPI_CLK, PA1=MOSI, PA2=MISO,P A3=SPI_SS */
     OEA |= 0x0B;   
     SPI_SS  = 1;
	 SPI_CLK = 0;
}

void TD_Poll(void)             // Called repeatedly while the device is idle
{ 
  // Serial State Notification that has to be sent periodically to the host

  if (!(EP1INCS & 0x02))      // check if EP1IN is available
  {
    EP1INBUF[0] = 0x0A;       // if it is available, then fill the first 10 bytes of the buffer with 
	EP1INBUF[1] = 0x20;       // appropriate data. 
	EP1INBUF[2] = 0x00;
	EP1INBUF[3] = 0x00;
	EP1INBUF[4] = 0x00;
	EP1INBUF[5] = 0x00;
	EP1INBUF[6] = 0x00;
	EP1INBUF[7] = 0x02;
    EP1INBUF[8] = 0x00;
	EP1INBUF[9] = 0x00;
  	EP1INBC = 10;            // manually commit once the buffer is filled
  }  
}

BOOL TD_Suspend(void)          // Called before the device goes into suspend mode
{
   return(TRUE);
}

BOOL TD_Resume(void)          // Called after the device resumes
{
   return(TRUE);
}

//-----------------------------------------------------------------------------
// Device Request hooks
//   The following hooks are called by the end point 0 device request parser.
//-----------------------------------------------------------------------------

BOOL DR_GetDescriptor(void)
{
   return(TRUE);
}

BOOL DR_SetConfiguration(void)   // Called when a Set Configuration command is received
{  

   Configuration = SETUPDAT[2];
   return(TRUE);            // Handled by user code
}

BOOL DR_GetConfiguration(void)   // Called when a Get Configuration command is received
{
   EP0BUF[0] = Configuration;
   EP0BCH = 0;
   EP0BCL = 1;
   return(TRUE);            // Handled by user code
}

BOOL DR_SetInterface(void)       // Called when a Set Interface command is received
{
   AlternateSetting = SETUPDAT[2];
   return(TRUE);            // Handled by user code
}

BOOL DR_GetInterface(void)       // Called when a Set Interface command is received
{
   EP0BUF[0] = AlternateSetting;
   EP0BCH = 0;
   EP0BCL = 1;
   return(TRUE);            // Handled by user code
}

BOOL DR_GetStatus(void)
{
   return(TRUE);
}

BOOL DR_ClearFeature(void)
{
   return(TRUE);
}

BOOL DR_SetFeature(void)
{
   return(TRUE);
}

BOOL DR_VendorCmnd(void)
{
   return(TRUE);
}

//-----------------------------------------------------------------------------
// USB Interrupt Handlers
//   The following functions are called by the USB interrupt jump table.
//-----------------------------------------------------------------------------

// Setup Data Available Interrupt Handler


void ISR_Sudav(void) interrupt 0
{
   
   GotSUD = TRUE;            // Set flag
   EZUSB_IRQ_CLEAR();
   USBIRQ = bmSUDAV;         // Clear SUDAV IRQ
}

// Setup Token Interrupt Handler
void ISR_Sutok(void) interrupt 0
{
   EZUSB_IRQ_CLEAR();
   USBIRQ = bmSUTOK;         // Clear SUTOK IRQ
}

void ISR_Sof(void) interrupt 0
{
   EZUSB_IRQ_CLEAR();
   USBIRQ = bmSOF;            // Clear SOF IRQ
}

void ISR_Ures(void) interrupt 0
{
   if (EZUSB_HIGHSPEED())
   {
      pConfigDscr = pHighSpeedConfigDscr;
      pOtherConfigDscr = pFullSpeedConfigDscr;
   }
   else
   {
      pConfigDscr = pFullSpeedConfigDscr;
      pOtherConfigDscr = pHighSpeedConfigDscr;
   }
   
   EZUSB_IRQ_CLEAR();
   USBIRQ = bmURES;         // Clear URES IRQ
}

void ISR_Susp(void) interrupt 0
{
    Sleep = TRUE;
   EZUSB_IRQ_CLEAR();
   USBIRQ = bmSUSP;
  
}

void ISR_Highspeed(void) interrupt 0
{
   if (EZUSB_HIGHSPEED())
   {
      pConfigDscr = pHighSpeedConfigDscr;
      pOtherConfigDscr = pFullSpeedConfigDscr;
   }
   else
   {
      pConfigDscr = pFullSpeedConfigDscr;
      pOtherConfigDscr = pHighSpeedConfigDscr;
   }

   EZUSB_IRQ_CLEAR();
   USBIRQ = bmHSGRANT;
}
void ISR_Ep0ack(void) interrupt 0
{
}
void ISR_Stub(void) interrupt 0
{
}
void ISR_Ep0in(void) interrupt 0
{
}
void ISR_Ep0out(void) interrupt 0
{


}
void ISR_Ep1in(void) interrupt 0
{
}

/* 
================================================================
=
= Function:     ISR_Ep1out
=
= Description:
=
= process sent bytes from pc
=
================================================================ 
*/
void ISR_Ep1out(void) interrupt 0
{
    unsigned int byte_count = 0;
	unsigned char response = 0;
	unsigned int i = 0;

	/* Clears the USB interrupt */
	EZUSB_IRQ_CLEAR();
	
	/* Clears EP1 OUT interrupt request */
	EPIRQ = bmBIT3;			

	/* store the number of bytes sent to device */
    byte_count = EP1OUTBC;
    
	/* did we get a command or is it data ? */
	if(byte_count <= 5)
	{
        /* make sure ss line is high before we process commands */
        SPI_SS = 1;

	    switch(EP1OUTBUF[0])
	    {
            case STATUS_READ:
		        /* read the devices status reg */
		        SPI_SS = 0;
	            spi_byte_write(EP1OUTBUF[0]);
				SYNCDELAY;
	            response = spi_byte_read();
	            SPI_SS = 1;

			    while((EP2468STAT & bmEP8EMPTY) == 0x00)
				{
                    /* wait for EP8 to be empty then send returned info back to pc  */
				}

			    EP8FIFOBUF [0] = response;    /* copies received data to ep8 */
			    EP8BCH = 0;    
			    SYNCDELAY;   
			    EP8BCL = 1;                   /* only send one byte response */
			    SYNCDELAY;  
		    break;

            case WRITE_ENABLE:
			    if((EP1OUTBUF[1] == BULK_ERASE) && (byte_count == 2))
                {
			        /* send write enable request */
				    SPI_SS = 0;
	                spi_byte_write(EP1OUTBUF[0]);
					SYNCDELAY;
				    SPI_SS = 1;
				    SYNCDELAY;
				    /*  then start bulk erase of device  */
                    SPI_SS = 0;
			        spi_byte_write(EP1OUTBUF[1]);
					SYNCDELAY;
				    SPI_SS = 1;
					SYNCDELAY;
			    }

			    if((EP1OUTBUF[1] == PAGE_WRITE) && (byte_count == 5))
			    {
			        /* send write enable request */
				    SPI_SS = 0;
	                spi_byte_write(EP1OUTBUF[0]);
					SYNCDELAY;
				    SPI_SS = 1;
				    SYNCDELAY;
                    /* tell the device which page we want to write too   */
			        /* and give it the data we want written to that page */
                    SPI_SS  = 0;
	                spi_byte_write(EP1OUTBUF[1]);
				    SYNCDELAY;
				    spi_byte_write(EP1OUTBUF[2]);
				    SYNCDELAY;
				    spi_byte_write(EP1OUTBUF[3]);
				    SYNCDELAY;
				    spi_byte_write(EP1OUTBUF[4]);
				    SYNCDELAY;
				    /* leave ss low as next packet will be data */
			    }	
            break;

		    case READ_FAST:
		        SPI_SS  = 0;
			    /* write page number to read from into device */
                for(i = 0 ; i < 5 ;i++)
			    {
	                spi_byte_write(EP1OUTBUF[i]);
				    SYNCDELAY;
			    }
           
			    while((EP2468STAT & bmEP8EMPTY) == 0x00)
				{
                    /* wait for EP8 to be empty then send returned info back to pc  */
				}

 		        /* read page data and send to pc */
                for(i = 0 ; i < PAGE_SIZE ;i++)
			    {
	                EP8FIFOBUF[i] = spi_byte_read();
					SYNCDELAY;
			    }

				EP8BCH = 1;    /* send 256 bytes (one page) */    
			    SYNCDELAY;   
			    EP8BCL = 0;    
			    SYNCDELAY;  

                SPI_SS = 1;
		    break;

		default:
            /* do nothing */
		break;
	    }
	}
	else
	{
	    /* max in packet size is 64 bytes so we need to get */
		/* 4 packets to make up 256 bytes one page          */
	    for(i = 0; i < byte_count; i++)
		{
	        spi_byte_write(EP1OUTBUF[i]);
			SYNCDELAY;
		}

        data_packet_cnt++; 

		/* if we got a whole page of data raise ss line */
		if(data_packet_cnt == 4)
		{
		    data_packet_cnt = 0;
	        SPI_SS = 1;
		}
	}

	/* Arms EP1 endpoint */
	EP1OUTBC = 0x04;
}

void ISR_Ep2inout(void) interrupt 0
{
}

void ISR_Ep4inout(void) interrupt 0
{

}
void ISR_Ep6inout(void) interrupt 0
{
}
void ISR_Ep8inout(void) interrupt 0
{
}
void ISR_Ibn(void) interrupt 0
{
}
void ISR_Ep0pingnak(void) interrupt 0
{
}
void ISR_Ep1pingnak(void) interrupt 0
{
}
void ISR_Ep2pingnak(void) interrupt 0
{
}
void ISR_Ep4pingnak(void) interrupt 0
{
}
void ISR_Ep6pingnak(void) interrupt 0
{
}
void ISR_Ep8pingnak(void) interrupt 0
{
}
void ISR_Errorlimit(void) interrupt 0
{
}
void ISR_Ep2piderror(void) interrupt 0
{
}
void ISR_Ep4piderror(void) interrupt 0
{
}
void ISR_Ep6piderror(void) interrupt 0
{
}
void ISR_Ep8piderror(void) interrupt 0
{
}
void ISR_Ep2pflag(void) interrupt 0
{
}
void ISR_Ep4pflag(void) interrupt 0
{
}
void ISR_Ep6pflag(void) interrupt 0
{
}
void ISR_Ep8pflag(void) interrupt 0
{
}
void ISR_Ep2eflag(void) interrupt 0
{
}
void ISR_Ep4eflag(void) interrupt 0
{
}
void ISR_Ep6eflag(void) interrupt 0
{
}
void ISR_Ep8eflag(void) interrupt 0
{
}
void ISR_Ep2fflag(void) interrupt 0
{
}
void ISR_Ep4fflag(void) interrupt 0
{
}
void ISR_Ep6fflag(void) interrupt 0
{
}
void ISR_Ep8fflag(void) interrupt 0
{
}
void ISR_GpifComplete(void) interrupt 0
{
}
void ISR_GpifWaveform(void) interrupt 0
{
}
